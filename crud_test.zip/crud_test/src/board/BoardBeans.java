package board;

public class BoardBeans {

	private int crud_ID;
	private String crud_title;
	private String crud_content;
	private String crud_userID;
	private int crud_available;
	
	public int getCrud_ID() {
		return crud_ID;
	}
	public void setCrud_ID(int crud_ID) {
		this.crud_ID = crud_ID;
	}
	public String getCrud_title() {
		return crud_title;
	}
	public void setCrud_title(String crud_title) {
		this.crud_title = crud_title;
	}
	public String getCrud_content() {
		return crud_content;
	}
	public void setCrud_content(String crud_content) {
		this.crud_content = crud_content;
	}
	public String getCrud_userID() {
		return crud_userID;
	}
	public void setCrud_userID(String crud_userID) {
		this.crud_userID = crud_userID;
	}
	public int getCrud_available() {
		return crud_available;
	}
	public void setCrud_available(int crud_available) {
		this.crud_available = crud_available;
	}
	
}
