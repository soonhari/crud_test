package member;

public class MemberBeans {

	private String crud_userID;
	private String crud_password;
	
	public String getCrud_userID() {
		return crud_userID;
	}
	public void setCrud_userID(String crud_userID) {
		this.crud_userID = crud_userID;
	}
	public String getCrud_password() {
		return crud_password;
	}
	public void setCrud_password(String crud_password) {
		this.crud_password = crud_password;
	}
	
}

